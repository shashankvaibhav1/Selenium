package august.eight;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

public class assignment8 {
  @Test
  public void test1() {
	  System.out.println("I met Mr. Dhoni");
  }
  @Test
  public void test2() {
	  System.out.println("I had my lunch with Mr. Virat Kholi");
  }
  @Test
  public void test3() {
	  System.out.println("I took a pic with Mr. Rohit Sharma");
  }
  
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("Hello");
  }

  @AfterMethod
  public void afterMethod() {
	  System.out.println("Bye");
  }

  @BeforeClass
  public void beforeClass() {
	  System.out.println("I came to the cricket Stadium");
  }

  @AfterClass
  public void afterClass() {
	  System.out.println("Now I am back home");
  }

}
