package august.eight;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class test1 {
	WebDriver dr1, dr2;
	String baseURL, nodeURL1, nodeURL2;
	@BeforeTest
	public void setup() throws MalformedURLException {
		baseURL = "http://www.facebook.com";
		nodeURL1 = "http://172.16.70.186:5566/wd/hub";	//satyam
		nodeURL2 = "http://172.16.41.122:5566/wd/hub";	//aditya
		DesiredCapabilities cap = DesiredCapabilities.firefox();
		cap.setBrowserName("firefox");
		cap.setPlatform(Platform.WINDOWS);
		dr1 = new RemoteWebDriver(new URL(nodeURL1),cap);
		dr2 = new RemoteWebDriver(new URL(nodeURL2),cap);
	}
	@AfterTest
	public void end() {
		//dr.quit();
	}
	@Test
	public void test1() {
		dr1.get(baseURL);
		dr2.get(baseURL);
	}
}
