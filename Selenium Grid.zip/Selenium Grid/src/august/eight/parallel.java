package august.eight;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;

public class parallel {
	WebDriver dr;
	@Test(priority =1)
	public void chrome() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_version_75.exe");
		dr = new ChromeDriver();
		dr.get("http://www.facebook.com");
	}
	@Test(priority =2)
	public void firefox() {
		System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
		dr = new FirefoxDriver();
		dr.get("http://www.facebook.com");
	}
	@Test(priority =3)
	public void ie() {
		System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
		dr = new InternetExplorerDriver();
		dr.get("http://www.facebook.com");
	}
	
}
