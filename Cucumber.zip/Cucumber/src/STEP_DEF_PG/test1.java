package STEP_DEF_PG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 {
	WebDriver dr;
  
  @Given("^Browser is launched & login page displayed$")
  public void browser_is_launched_login_page_displayed() throws Throwable {
      System.out.println("in given");
      System.setProperty("webdriver.chrome.driver", "chromedriver_version_75.exe");
      dr = new ChromeDriver();
      dr.get("https://www.facebook.com");
  }

  @When("^User enters login credentials & clicks on login$")
  public void user_enters_login_credentials_clicks_on_login() throws Throwable {
	  System.out.println("in when");
	  dr.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("+18452435930");
	  dr.findElement(By.xpath("//*[@id=\"pass\"]")).sendKeys("abcdefg123");
	  dr.findElement(By.xpath("//*[@id=\"loginbutton\"]")).click();
	  
  }

  @Then("^Successful login happen & profile name displayed correctly$")
  public void successful_login_happen_profile_name_displayed_correctly() throws Throwable {
	  System.out.println("in then");
	  String expected = "Ram";
	  String actual = dr.findElement(By.xpath("//*[@id=\"u_0_a\"]/div[1]/div[1]/div/a/span/span")).getText();
	  Assert.assertEquals(actual, expected);
	  System.out.println("Success");
  }
}
