package STEP_DEF_PG;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test2 {
	
	webdriver wd = new webdriver();
	
	@Given("^lauch the browser$")
	public void lauch_the_browser() throws Throwable {
		wd.launch_browser();
	}

	@When("^login for admin$")
	public void login_for_admin() throws Throwable {
		wd.admin_login();
	}

	@When("^add a new category$")
	public void add_a_new_category() throws Throwable {
		wd.add_category();
	}

	@Then("^verify for category$")
	public void verify_for_category() throws Throwable {
		String data = wd.verify_category();
		System.out.println(data);
		wd.exit();
	}
	
	@When("^add a new Products$")
	public void add_a_new_Products() throws Throwable {
		wd.add_product();
	}

	@Then("^verify for Products$")
	public void verify_for_Products() throws Throwable {
	    String data = wd.verify_product();
		System.out.println(data);
		wd.exit();
	}
	
	
	
}
