package STEP_DEF_PG;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class webdriver {
	WebDriver dr;
	WebDriverWait wait;
	Logger log;
	String category_name = "ABCD";
	String product_name = "ABCDEFGH";
	String price = "50";
	public void launch_browser() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_version_75.exe");
		dr = new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		waiting("Online Bookstore");
	}
	public void waiting(String title) {
		wait=new WebDriverWait(dr, 20);
		wait.until(ExpectedConditions.titleContains(title));
	}
	
	public void admin_login() {
		dr.findElement(By.xpath("//a[contains(text(),'Administration')]")).click();
		dr.findElement(By.xpath("//input[@name=\"login\"]")).sendKeys("admin");
		dr.findElement(By.xpath("//input[@name=\"password\"]")).sendKeys("admin");
		dr.findElement(By.xpath("//input[@name=\"DoLogin\"]")).click();
		waiting("AdmMenu");
		log = Logger.getLogger("devpinoyLogger");
		log.info("admin_login executed");
	}
	
	public void add_category() {
		dr.findElement(By.xpath("//a[contains(text(),'Categories')]")).click();
		waiting("AdmCategories");
		dr.findElement(By.xpath("//a[contains(text(),'Add New')]")).click();
		waiting("AdmCategoryRecord");
		dr.findElement(By.xpath("//input[@name=\"category_name\"]")).sendKeys(category_name);
		dr.findElement(By.xpath("//input[@name=\"Insert1\"]")).click();
		log.info("add_category executed");
	}
	
	public String verify_category() {
		waiting("AdmCategories");
		boolean verify = false;
		boolean next = false;
		try {
		 next = dr.findElement(By.xpath("//a[text()='Next']")).isDisplayed();
		}catch(Exception e) {}
		
		do {
			try {
				verify = dr.findElement(By.xpath("//a[text()='"+category_name+"']")).isDisplayed();
				wait=new WebDriverWait(dr, 40);
				wait.until(ExpectedConditions.textToBe(By.xpath("//a[text()='"+category_name+"']"), category_name));
				if(verify)
					break;
			}catch(Exception e) {
				System.out.println("Not find in current page");
				dr.findElement(By.xpath("//a[text()='Next']")).click();
			}
		}
		while(next);
		log.info("verify_category executed");
		return "Sucess";
	}
	
	public void add_product() {
		dr.findElement(By.xpath("//a[text()='Products']")).click();
		waiting("AdmProducts");
		dr.findElement(By.xpath("//a[contains(text(),'Add New')]")).click();
		waiting("AdmProductRecord");
		dr.findElement(By.xpath("//option[text()='"+category_name+"']")).click();
		dr.findElement(By.xpath("//input[@name='product_name']")).sendKeys(product_name);
		dr.findElement(By.xpath("//input[@name='price']")).sendKeys(price);
		dr.findElement(By.xpath("//input[@name=\"Insert1\"]")).click();
		log.info("add_product executed");
	}
	
	public String verify_product() {
		waiting("AdmProducts");
		boolean verify = false;
		boolean next = false;
		try {
		 next = dr.findElement(By.xpath("//a[text()='Next']")).isDisplayed();
		}catch(Exception e) {}
		
		do {
			try {
				verify = dr.findElement(By.xpath("//a[text()='"+product_name+"']")).isDisplayed();
				wait=new WebDriverWait(dr, 40);
				wait.until(ExpectedConditions.textToBe(By.xpath("//a[text()='"+product_name+"']"), product_name));
				if(verify)
					break;
			}catch(Exception e) {
				System.out.println("Not find in current page");
				dr.findElement(By.xpath("//a[text()='Next']")).click();
			}
		}
		while(next);
		log.info("verify_product executed");
		return "Success";
	}
	public void exit() {
		dr.quit();
	}
	
}
