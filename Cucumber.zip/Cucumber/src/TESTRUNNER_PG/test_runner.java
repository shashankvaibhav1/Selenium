package TESTRUNNER_PG;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features = "FEATURES", glue = "STEP_DEF_PG")

public class test_runner extends AbstractTestNGCucumberTests {
	
}
