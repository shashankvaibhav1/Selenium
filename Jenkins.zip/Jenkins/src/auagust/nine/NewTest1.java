package auagust.nine;

import org.testng.annotations.Test;

public class NewTest1 {
  @Test
  public void f() {
	  System.out.println("Hello: Test1");
  }
}
