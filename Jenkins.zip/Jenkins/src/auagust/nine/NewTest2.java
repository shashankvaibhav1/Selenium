package auagust.nine;

import org.testng.annotations.Test;

public class NewTest2 {
  @Test
  public void f() {
	  System.out.println("Hello: Test2");
  }
}
