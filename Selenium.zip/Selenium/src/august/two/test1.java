package august.two;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class test1 {

	public void accept() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_version_75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demo.guru99.com/test/delete_customer.php");
		dr.findElement(By.xpath("//input[@name= 'cusid']")).sendKeys("asd");
		dr.findElement(By.xpath("//input[@name= 'submit']")).click();
		System.out.println(dr.switchTo().alert().getText());
		dr.switchTo().alert().accept();
		System.out.println(dr.switchTo().alert().getText());
		dr.switchTo().alert().accept();
		dr.close();
	}
	public void dismis() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_version_75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demo.guru99.com/test/delete_customer.php");
		dr.findElement(By.xpath("//input[@name= 'cusid']")).sendKeys("asd");
		dr.findElement(By.xpath("//input[@name= 'submit']")).click();
		System.out.println(dr.switchTo().alert().getText());
		dr.switchTo().alert().dismiss();
		dr.close();
	}
}
