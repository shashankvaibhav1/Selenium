package august.two;

import org.testng.annotations.Test;

public class Testcase extends test1{
	
	  @Test
	  public void f1() {
		  accept();
	  }
	  @Test
	  public void f2() {
		  dismis();
	  }
}
