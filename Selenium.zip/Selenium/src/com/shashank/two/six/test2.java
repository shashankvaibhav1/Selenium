package com.shashank.two.six;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.support.ui.Select;

public class test2 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","chromedriver_version_75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.facebook.com");
		
		WebElement we = dr.findElement(By.id("day"));
		Select sel = new Select(we);
		sel.selectByVisibleText("10");
		
	}

}
