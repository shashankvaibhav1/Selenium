package com.shashank.two.six;

import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;

public class test1 {

	public static void main(String[] args) {
//		ChromeOptions options = new ChromeOptions();
//		options.addArguments("--disable notification");
		System.setProperty("webdriver.chrome.driver","chromedriver_version_75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.facebook.com");
		String abc = dr.findElement(By.xpath("//*[text()='Email or Phone']")).getText();
		System.out.println(abc);
		String abcd = dr.findElement(By.xpath("//*[contains(text(),'Create an')]")).getText();
		System.out.println(abcd);
		dr.findElement(By.xpath("//input[@name = 'firstname']//following::input[1]")).click();
		List<WebElement> rb = dr.findElements(By.name("sex"));
		rb.get(0).click();
		//rb.get(2).click();
		/*
		 * dr.findElement(By.id("email")).sendKeys("+18452435930");
		 * dr.findElement(By.cssSelector("input#email")).clear();
		 * dr.findElement(By.id("pass")).sendKeys("abcdefg123");
		 * dr.findElement(By.cssSelector("input[type='submit']")).click();
		 * //dr.findElement(By.id("loginbutton")).click();
		 * dr.findElement(By.partialLinkText("Forgotten")).click();
		 * 
		 * String name = dr.getTitle(); System.out.println("Page Name-"+name); String
		 * profile_name =
		 * dr.findElement(By.xpath("//*[@id=\"u_0_a\"]/div[1]/div[1]/div/a/span/span")).
		 * getText(); System.out.println("Profile Name:"+profile_name); //
		 * dr.findElement(By.id("userNavigationLabel")).click(); //
		 * dr.findElement(By.className("_54nh")).click(); String xyz = "232"; int i =
		 * Integer.parseInt(xyz); System.out.println(i);
		 */
	}

}
