package com.shashank.three.zero;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class test1 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","chromedriver_version_75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://www.echoecho.com/htmlforms09.htm");
		
		Boolean cs = dr.findElement(By.name("option1")).isSelected();
		Boolean fs = true;
		
		if(cs==false) {
			if(fs==true) {
				dr.findElement(By.name("option1")).click();
			}
		}else {
			if(fs==false) {
				dr.findElement(By.name("option1")).click();
			}
		}
		
		

	}

}
