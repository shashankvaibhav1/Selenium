package com.shashank.three.zero;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

//question 2

public class test4 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","chromedriver_version_75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		if(dr.getTitle().equals("Online Bookstore")) {
			dr.findElement(By.xpath("//option[@value = 2]")).click();
			dr.findElement(By.xpath("//input[@name = \"DoSearch\"]")).click();
			dr.close();
		}
	}

}
