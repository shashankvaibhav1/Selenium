package com.shashank.three.zero;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

//question 5


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class test5 {

	public static void main(String[] args) throws Exception{
		System.setProperty("webdriver.chrome.driver","chromedriver_version_75.exe");
		WebDriver dr = new ChromeDriver();
		for(int i=1;i<=4;i++)
		{
			dr.get("http://demowebshop.tricentis.com");
			dr.findElement(By.linkText("Log in")).click();
			if(dr.getTitle().equals("Demo Web Shop. Login")) {
				ArrayList al = new ArrayList();
				al.add(read_excel(i).get(0));
				al.add(read_excel(i).get(1));
				al.add(read_excel(i).get(2));
				String email = al.get(0).toString();
				String pass = al.get(1).toString();
				dr.findElement(By.id("Email")).sendKeys(email);
				dr.findElement(By.id("Password")).sendKeys(pass);
				dr.findElement(By.xpath("//input[@value=\"Log in\"]")).click();
				if(dr.getTitle().equals("Demo Web Shop")) {
					if((dr.findElement(By.linkText(email)).getText()).equals(al.get(2).toString()))
					{
						dr.findElement(By.xpath("//a[contains(text(),'Log out')]")).click();
						update_excel(i, al.get(0).toString(), "PASS");
					}
				}else {
					String msg1 = "The credentials provided are incorrect";
					String msg2 = "Please enter a valid email address.";
					String msg3 = "No customer account found";
					//System.out.println((dr.findElement(By.xpath("//div[@class = 'validation-summary-errors']")).getText()).contains(msg1));
					//By.xpath("//*[contains(text(),'"+msg1+"')]")).isDisplayed()
					try {
					if((dr.findElement(By.xpath("//div[@class = 'validation-summary-errors']")).getText()).contains(msg1)) {
						update_excel(i, "Login was unsuccessful. Please correct the errors and try again. The credentials provided are incorrect", "PASS");
						//continue;
					}}catch(Exception e) {}
					try {
					if((dr.findElement(By.xpath("//span[@class = 'field-validation-error']")).getText()).contains(msg2)) {
							update_excel(i, "Please enter a valid email address.", "PASS");
						//continue;
					}}catch(Exception e) {}
					try {
					if((dr.findElement(By.xpath("//div[@class = 'validation-summary-errors']")).getText()).contains(msg3)) {
						update_excel(i, "Login was unsuccessful. Please correct the errors and try again. No customer account found", "PASS");
						//continue;
					}}catch(Exception e) {}
				}
			}
		}
		
	}
	public static void update_excel(int i, String actual, String result) {
		try {
			File f = new File("d:\\abc.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheetAt(0);
			XSSFRow row = sh.getRow(i);
			fis.close();
			FileOutputStream fos = new FileOutputStream(f);
			row.createCell(3).setCellValue(actual);
			row.createCell(4).setCellValue(result);
			wb.write(fos);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public static ArrayList read_excel(int i) {
		ArrayList al =  new ArrayList();
		try {
			File f = new File("d:\\abc.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheetAt(0);
			XSSFRow row = sh.getRow(i);
			al.add(row.getCell(0));
			al.add(row.getCell(1));
			al.add(row.getCell(2));
		}catch(Exception e) {
			e.printStackTrace();
		}
		return al;
	}
}
