package com.shashank.three.zero;

//question 1

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class test2 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","chromedriver_version_75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.linkText("Register")).click();
		if(dr.getTitle().equals("Demo Web Shop. Register")) {
			List<WebElement> lt = dr.findElements(By.name("Gender"));
			lt.get(0).click();
			String email = "abcz450@gmail.com";
			dr.findElement(By.id("FirstName")).sendKeys("Shashank");
			dr.findElement(By.id("LastName")).sendKeys("Vaibhav");
			dr.findElement(By.id("Email")).sendKeys(email);
			dr.findElement(By.id("Password")).sendKeys("abcdef");
			dr.findElement(By.id("ConfirmPassword")).sendKeys("abcdef");
			dr.findElement(By.id("register-button")).click();
			System.out.println(dr.findElement(By.className("result")).getText());
			if((dr.findElement(By.className("result")).getText()).equals("Your registration completed")) {
				//dr.findElement(By.className("button-1 register-continue-button")).click();
				dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[2]/input")).click();
				System.out.println(dr.findElement(By.linkText(email)).getText());
				if((dr.findElement(By.linkText(email)).getText()).equals(email))
					dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
			}
		}
	}

}
