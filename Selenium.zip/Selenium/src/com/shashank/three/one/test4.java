package com.shashank.three.one;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

//Q8

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class test4 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","chromedriver_version_75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		
		WebElement we = dr.findElement(By.xpath("//a[contains(text(),'Computers')]"));
		
		Actions act = new Actions(dr);
		
		Action set1 = act.moveToElement(we).build();
		set1.perform();
		
		WebElement we1 = dr.findElement(By.xpath("//a[contains(text(),'Accessories')]"));
		
		Action set2 = act.moveToElement(we1).click().build();
		set2.perform();
		
		WebDriverWait wt = new WebDriverWait(dr,10);
		wt.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Register')]")));
		dr.findElement(By.xpath("//a[contains(text(),'Register')]")).click();
		
		dr.navigate().back();
		dr.navigate().forward();
		
		dr.get("http://www.facebook.com");
		WebElement we2 = dr.findElement(By.xpath("//input[@name = 'firstname']"));
		
		Actions act1 = new Actions(dr);
		
		Action set3 = act1.moveToElement(we2)
				.click(we2)
				.sendKeys("RAM")
				.keyDown(we2, Keys.CONTROL)
				.sendKeys("A")
				.sendKeys("c")
				.keyUp(we2, Keys.CONTROL)
				.build();
		
		set3.perform();
		
		WebElement we3 = dr.findElement(By.xpath("//input[@name = 'lastname']"));
		
		Action set4 = act1.moveToElement(we3)
//				.click(we3)
				.keyDown(we3, Keys.CONTROL)
				.sendKeys("v")
				.keyUp(we3, Keys.CONTROL)
				.build();
		
		set4.perform();
	}

}
