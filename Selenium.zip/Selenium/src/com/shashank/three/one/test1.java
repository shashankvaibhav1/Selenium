package com.shashank.three.one;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

//Q5
public class test1 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","chromedriver_version_75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		String pname = "";
		String price = "";
		float price_val;
		int quantity = 2;
		float total_price;
		if(dr.getTitle().equals("Online Bookstore")) {
			dr.findElement(By.xpath("//option[@value = 2]")).click();
			dr.findElement(By.xpath("//input[@name = \"DoSearch\"]")).click();
			dr.findElement(By.xpath("//a[text()=\"Web Database Development\"]")).click();
			pname = (dr.findElement(By.xpath("//h1[text()=\"Web Database Development\"]")).getText());
			if(pname.equals("Web Database Development")) {
				//System.out.println(pname);
				price = dr.findElement(By.xpath("//td[contains(text(), 'Price')]")).getText();
				//System.out.println(price.replaceAll("[^0-9.]+", ""));
				price_val = Float.parseFloat(price.replaceAll("[^0-9.]+", ""));
				//System.out.println(price_val);
				dr.findElement(By.xpath("//input[@name='quantity']")).clear();
				dr.findElement(By.xpath("//input[@name='quantity']")).sendKeys("2");
				dr.findElement(By.xpath("//input[@name='Insert1']")).click();
				total_price = price_val*quantity;
				String price_disp = dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[4]")).getText();
				float tp_disp = Float.parseFloat(price_disp.replaceAll("[^0-9.]+", ""));
				//System.out.println(tp_disp);
				if(tp_disp == total_price) {
					System.out.println("Successful");
					dr.close();
				}
			}
			
			//dr.close();
		}
		
	}
}