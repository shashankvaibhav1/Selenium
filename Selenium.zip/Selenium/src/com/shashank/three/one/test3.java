package com.shashank.three.one;

//Q7

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class test3 {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","chromedriver_version_75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://examples.codecharge.com/RegistrationForm/Registration.php");
		dr.findElement(By.xpath("//input[@name = 'user_login']")).sendKeys("az126");
		dr.findElement(By.xpath("//input[@name = 'user_password']")).sendKeys("abcdef");
		dr.findElement(By.xpath("//input[@name = 'first_name']")).sendKeys("ABC");
		dr.findElement(By.xpath("//input[@name = 'last_name']")).sendKeys("DEF");
		dr.findElement(By.xpath("//input[@name = 'email']")).sendKeys("az126@gmail.com");
		dr.findElement(By.xpath("//input[@name = 'address1']")).sendKeys("ABCDEFGHI");
		dr.findElement(By.xpath("//input[@name = 'address2']")).sendKeys("JKLMNOPQRST");
		dr.findElement(By.xpath("//input[@name = 'address3']")).sendKeys("UVWXYZ");
		dr.findElement(By.xpath("//input[@name = 'city']")).sendKeys("Mirzapur");
		dr.findElement(By.xpath("//select[@name= 'state_id']//option[@value = 3]")).click();
		dr.findElement(By.xpath("//input[@name = 'zip']")).sendKeys("82713");
		dr.findElement(By.xpath("//select[@name= 'country_id']//option[@value = 112]")).click();
		dr.findElement(By.xpath("//input[@name = 'phone_home']")).sendKeys("8278989013");
		dr.findElement(By.xpath("//input[@name = 'phone_work']")).sendKeys("9966827013");
		dr.findElement(By.xpath("//select[@name= 'language_id']//option[@value = 1]")).click();
		dr.findElement(By.xpath("//select[@name= 'age_id']//option[@value = 3]")).click();
		dr.findElement(By.xpath("//select[@name= 'gender_id']//option[@value = 1]")).click();
		dr.findElement(By.xpath("//select[@name= 'education_id']//option[@value = 2]")).click();
		dr.findElement(By.xpath("//select[@name= 'income_id']//option[@value = 2]")).click();
		dr.findElement(By.xpath("//textarea[@name = 'note']")).sendKeys("Dont Know");
		dr.findElement(By.xpath("//input[@name = 'Insert']")).click();
		if(dr.getTitle().equals("Registration Form")) {
			System.out.println("Success");
			dr.close();
		}
		else {
			System.out.println("The value in field Login is already in database.");
		}
	}
}
