package com.shashank.three.one;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

//Q6
public class test2 {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","chromedriver_version_75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		float p1 = add(dr,1,"Programming Perl","2",1);
		float p2 = add(dr,2,"Web Database Development","3",2);
		float p3 = add(dr,3,"Flash 4 Magic","1",3);
		float total = p1+p2+p3;
		String str = dr.findElement(By.xpath("//*[contains(text(),'Total:')]//ancestor::p")).getText();
		float actual_val = Float.parseFloat(str.replaceAll("[^0-9.]+", ""));
		if(actual_val == total) {
			System.out.print("Successful");
		}
	}
	public static float add(WebDriver dr, int option, String bookname, String quantity,int count) {
		String pname = "";
		String price = "";
		float price_val;
		float total_price;
		dr.findElement(By.xpath("/html/body/table[2]/tbody/tr/td/a[1]")).click();
		if(dr.getTitle().equals("Online Bookstore")) {
			dr.findElement(By.xpath("//option[@value = "+option+"]")).click();
			dr.findElement(By.xpath("//input[@name = \"DoSearch\"]")).click();
			//System.out.println("//a[text()='"+bookname+"']");
			dr.findElement(By.xpath("//a[text()='"+bookname+"']")).click();
			pname = (dr.findElement(By.xpath("//h1[text()='"+bookname+"']")).getText());
			if(pname.equals(bookname)) {
				price = dr.findElement(By.xpath("//td[contains(text(), 'Price')]")).getText();
				price_val = Float.parseFloat(price.replaceAll("[^0-9.]+", ""));
				dr.findElement(By.xpath("//input[@name='quantity']")).clear();
				dr.findElement(By.xpath("//input[@name='quantity']")).sendKeys(quantity);
				dr.findElement(By.xpath("//input[@name='Insert1']")).click();
				total_price = price_val*Integer.parseInt(quantity);
				String price_disp = dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr["+(count+1)+"]/td[4]")).getText();
				float tp_disp = Float.parseFloat(price_disp.replaceAll("[^0-9.]+", ""));
				if(tp_disp == total_price) {
					return tp_disp;
				}
			}
		}
		count++;
		return (Float) null;
	}
}