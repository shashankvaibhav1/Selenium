package august.five.kd_framework;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

public class NewTest {
  @Test(dataProvider = "dp")
  public void f(String email, String pwd, String verify) {
	  Assert.assertEquals(pwd, verify);
  }

  @DataProvider
  public String[][] dp() {
	  String test[][] = {
			  {"abc@gmail.com", "abc", "abc"},
			  {"abcd@gmail.com", "abcd", "abcd"}
	  };
	  return test;
  }
  @BeforeClass
  public void beforeClass() {
	  System.out.println("Class Started");
  }

}
