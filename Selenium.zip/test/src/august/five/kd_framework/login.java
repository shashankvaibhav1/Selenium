package august.five.kd_framework;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class login {
	//public String user_action;
	public String keyword;
	public String xpath;
	public String test_data;
	public String test_result;
	
	public login read_excel(int i) {
		login al =  new login();
		try {
			File f = new File("test_data.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheetAt(0);
			XSSFRow row = sh.getRow(i);
			al.keyword = row.getCell(1).getStringCellValue();
			al.xpath = row.getCell(2).getStringCellValue();
			al.test_data = row.getCell(3).getStringCellValue();
		}catch(Exception e) {
		}
		return al;
	}
	public void update_excel(String result) {
		try {
			File f = new File("test_data.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheetAt(0);
			XSSFRow row = sh.getRow(6);
			fis.close();
			FileOutputStream fos = new FileOutputStream(f);
			row.createCell(4).setCellValue(result);
			wb.write(fos);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
