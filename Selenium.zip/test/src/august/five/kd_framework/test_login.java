package august.five.kd_framework;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class test_login {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","chromedriver_version_75.exe");
		WebDriver dr = new ChromeDriver();
		login lg = new login();
		ArrayList<login> al = new ArrayList<login>();
		for(int i=1; i<7; i++){
			al.add(lg.read_excel(i));
			//System.out.println(al.get(i-1).test_data);
		}
		try {
			for(int i=0; i<7; i++){
				switch(al.get(i).keyword) {
					case "launch":
						String test_data = al.get(i).test_data;
						//System.out.println(test_data);
						dr.get(test_data);
						break;
					case "click": dr.findElement(By.xpath(al.get(i).xpath)).click();
						break;
					case "enter_txt": dr.findElement(By.xpath(al.get(i).xpath)).sendKeys(al.get(i).test_data);
						break;
					case "verify": 
						if((dr.findElement(By.xpath(al.get(i).xpath)).getText()).equals(al.get(i).test_data)) {
							System.out.println("Success");
							lg.update_excel("PASS");
							dr.quit();
						}else {
							System.out.println("Failure");
							lg.update_excel("FAIL");
						}
						break;
					default: System.out.println("None of Case");
						break;				
						
				}
			}
		}catch(Exception e) {}

	}

}
