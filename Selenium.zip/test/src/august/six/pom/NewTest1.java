package august.six.pom;

import org.testng.annotations.Test;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

public class NewTest1 {
	
	Logger log;
	
	WebDriver dr;
	fbLoginPage login_page;
	fbHomePage home_page;
	
	@BeforeClass
	public void beforeClass() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_version_75.exe");
		dr = new ChromeDriver();
		dr.get("https://www.facebook.com");
	}
	
	@Test(priority = 1)
	public void test_login() {
		login_page = new fbLoginPage(dr);
		String login_page_title = login_page.get_title();
		System.out.println("Title : "+ login_page_title);
		log = log.getLogger("devpinoyLogger");
		log.info("test1 executed");
	}
	
	@Test(priority = 2)
	public void test_home() {
		login_page.do_login("+18452435930", "abcdefg123");
		home_page = new fbHomePage(dr);
		String actual_pname = home_page.get_profilename();
		System.out.println("Profile Name : "+ actual_pname);
		Assert.assertEquals(actual_pname, "Ram");
		log.info("test2 executed");
		
	}

}
