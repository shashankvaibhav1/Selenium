package august.two.test;

import org.testng.annotations.*;

public class testcase2 {
	
	/*
	 * @BeforeClass public void bc() { System.out.println("===START==="); }
	 * 
	 * @AfterClass public void ac() { System.out.println("===END==="); }
	 */
	@Test(priority = 1)
	public void a() {
		System.out.println("a is called");
	}
	@Test(priority = 2)
	public void b() {
		System.out.println("b is called");
	}
	@BeforeMethod
	public void test1() {
		System.out.println("Getting start---------->");
	}
	@AfterMethod
	public void test2() {
		System.out.println("Getting end------------>");
	}
}
