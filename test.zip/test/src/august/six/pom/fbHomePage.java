package august.six.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class fbHomePage {
	WebDriver dr;
	
	By profile_xpath = By.xpath("//*[@id=\"u_0_a\"]/div[1]/div[1]/div/a/span/span");
	
	public fbHomePage(WebDriver dr) {
		this.dr = dr;
	}
	public String get_profilename() {
		return dr.findElement(profile_xpath).getText();
	}
}
