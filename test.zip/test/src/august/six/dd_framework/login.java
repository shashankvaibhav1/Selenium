package august.six.dd_framework;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class login {
	//public String user_action;
	public String email;
	public String pass;
	public String er;
	
	public void update_excel(int i, String actual, String result) {
		try {
			File f = new File("abc.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheetAt(0);
			XSSFRow row = sh.getRow(i);
			fis.close();
			FileOutputStream fos = new FileOutputStream(f);
			row.createCell(3).setCellValue(actual);
			row.createCell(4).setCellValue(result);
			wb.write(fos);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public login read_excel(int i) {
		login al =  new login();
		try {
			File f = new File("d:\\abc.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheetAt(0);
			XSSFRow row = sh.getRow(i);
			al.email = row.getCell(0).getStringCellValue();
			al.pass = row.getCell(1).getStringCellValue();
			al.er = row.getCell(2).getStringCellValue();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return al;
	}

}
