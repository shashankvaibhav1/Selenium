package august.two.test;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import august.two.code.login;

public class testcase {
	String email = "";
	String pass = "";
	String expected = "";
	@BeforeClass
	public void bc() {
		System.out.println("===START===");
	}
	@AfterClass
	public void ac() {
		System.out.println("===END===");
	}
	@Test
	public void test1() {
		this.email = "abcz450@gmail.com";
		this.pass = "abcdef";
		this.expected = "abcz450@gmail.com";
		login lg = new login();
		String actual = lg.get_login(this.email, this.pass);
		Assert.assertEquals(actual, this.expected);
	}
	@Test
	public void test2() {
		this.email = "abc450@gmail.com";
		this.pass = "abcdef";
		this.expected = "abc450@gmail.com";
		login lg = new login();
		String actual = lg.get_login(this.email, this.pass);
		Assert.assertEquals(actual, this.expected);
	}
}
