package august.two.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import august.two.code.DemoWebShop;

public class testcase3 {
	String email = "";
	String pass = "";
	WebDriver dr;
	DemoWebShop dws = new DemoWebShop();
	@BeforeMethod
	public void bm() {
		System.setProperty("webdriver.chrome.driver","chromedriver_version_75.exe");
		dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.linkText("Log in")).click();
	}
	@Test
	public void test1() {
		this.email = "abcz450@gmail.com";
		this.pass = "abcdef";
		String actual = dws.login(dr,this.email,this.pass);
		String expected = "abcz450@gmail.com";
		//Assert.assertEquals(actual, expected);
		SoftAssert sa = new SoftAssert();
		sa.assertEquals(actual, expected);
		System.out.println("Test Case 1");
		sa.assertAll();
	}
	
	@Test
	public void test2() {
		this.email = "abc450@gmail.com";
		this.pass = "abcdf";
		String actual = dws.login(dr,this.email,this.pass);
		String expected = "Login was unsuccessful. Please correct the errors and try again.\nNo customer account found";
		Assert.assertEquals(actual, expected);
	}
	
	@Test
	public void test3() {
		this.email = "abc450@gmai";
		this.pass = "abcdef";
		String actual = dws.login(dr,this.email,this.pass);
		String expected = "Please enter a valid email address.";
		Assert.assertEquals(actual, expected);
	}
	
	
	@AfterMethod
	public void am() {
		dr.quit();
	}
}
