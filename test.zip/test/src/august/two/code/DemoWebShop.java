package august.two.code;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DemoWebShop {
	public String login(WebDriver dr, String email, String pass) {
		dr.findElement(By.id("Email")).sendKeys(email);
		dr.findElement(By.id("Password")).sendKeys(pass);
		dr.findElement(By.xpath("//input[@value=\"Log in\"]")).click();
		try {
			return dr.findElement(By.linkText(email)).getText();
		}catch(Exception e) {
			//e.printStackTrace();
		}
		try {
			return dr.findElement(By.xpath("//div[@class = 'validation-summary-errors']")).getText();
		}catch(Exception e) {
			//e.printStackTrace();
		}
		try {
			return dr.findElement(By.xpath("//span[@class = 'field-validation-error']")).getText();
		}catch(Exception e) {
			//.printStackTrace();
		}
		return null;
	}
}
