package august.two.code;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class login {
	
	public String get_login(String email, String pass) {
		System.setProperty("webdriver.chrome.driver","chromedriver_version_75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.linkText("Log in")).click();
		dr.findElement(By.id("Email")).sendKeys(email);
		dr.findElement(By.id("Password")).sendKeys(pass);
		dr.findElement(By.xpath("//input[@value=\"Log in\"]")).click();
//		if(dr.getTitle().equals("Demo Web Shop")) {
//			if((dr.findElement(By.linkText(email)).getText()).equals(al.get(2).toString())){
//				dr.findElement(By.xpath("//a[contains(text(),'Log out')]")).click();
//			}
//		}
		String actual = dr.findElement(By.linkText(email)).getText();
		dr.close();
		return actual;
		
	}
	
}
