package august.five.kd_framework;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class test_login {
	static WebDriver dr;
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","chromedriver_version_75.exe");
		login_details lg_det = new login_details();
		ArrayList<login_details> tcd = new ArrayList<login_details>();
		for(int i=1; i<4; i++){
			tcd.add(lg_det.read_excel(i));
			//System.out.println("1");
		}
		for(int i=0; i<3; i++){
			if((tcd.get(i).flag).equals("Y")) {
				login_tc(tcd.get(i).tc_id, tcd.get(i).no_test);
				lg_det.update_excel(i, "PASS");
			}
		}
	}
	public static void login_tc(String tc_id, int no_test) {
		login lg = new login();
		ArrayList<login> al = new ArrayList<login>();
		for(int i=1; i<19; i++){
			//System.out.println(lg.read_excel(i).tc_id);
			if((lg.read_excel(i).tc_id).equals(tc_id)) {
				al.add(lg.read_excel(i));
			}	
		}
		try {
			for(int i=0; i<7; i++){
				int j = al.get(i).line;
				//System.out.println(j);
				if((al.get(i).tc_id).equals(tc_id)) {
					switch(al.get(i).keyword) 
					{
						case "launch":
							String test_data = al.get(i).test_data;
							dr = new ChromeDriver();
							dr.get(test_data);
							break;
						case "click": dr.findElement(By.xpath(al.get(i).xpath)).click();
							break;
						case "enter_txt": dr.findElement(By.xpath(al.get(i).xpath)).sendKeys(al.get(i).test_data);
							break;
						case "verify": 
							if((dr.findElement(By.xpath(al.get(i).xpath)).getText()).equals(al.get(i).test_data)) {
								System.out.println("Success");
								lg.update_excel(j, "PASS");
								dr.quit();
							}else {
								System.out.println("Failure");
								lg.update_excel(j, "FAIL");
							}
							break;
						default: System.out.println("None of Case");
							break;				
							
					}
				}
				
			}
		}catch(Exception e) {}
	}

}
