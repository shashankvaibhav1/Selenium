package august.five.kd_framework;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class login_details {
	//public String user_action;
	public String tc_id;
	public String flag;
	public int no_test;
	public String test_result;
	
	public login_details read_excel(int i) {
		login_details al =  new login_details();
		try {
			File f = new File("test_data.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheetAt(1);
			XSSFRow row = sh.getRow(i);
			al.tc_id = row.getCell(0).getStringCellValue();
			al.flag = row.getCell(1).getStringCellValue();
			al.no_test = (int) row.getCell(2).getNumericCellValue();
		}catch(Exception e) {
		}
		return al;
	}
	public void update_excel(int i, String result) {
		try {
			File f = new File("test_data.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheetAt(1);
			XSSFRow row = sh.getRow(i+1);
			fis.close();
			FileOutputStream fos = new FileOutputStream(f);
			row.createCell(3).setCellValue(result);
			wb.write(fos);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
