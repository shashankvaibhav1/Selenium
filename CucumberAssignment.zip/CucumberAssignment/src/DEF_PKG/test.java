package DEF_PKG;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test {
	WebDriver dr;
	ArrayList<WebElement> al;
	WebDriverWait wait;
	Logger log = Logger.getLogger("devpinoyLogger");
	
	@Given("^launch browser and goto admin page$")
	public void launch_browser_and_goto_admin_page() throws Throwable {
	  //System.out.println("launch browser and goto admin page");
	    System.setProperty("webdriver.chrome.driver", "chromedriver_version_75.exe");
	    dr = new ChromeDriver();
	    dr.manage().window().maximize();
	    dr.get("http://examples.codecharge.com/Store/Default.php");
	    dr.findElement(By.xpath("//a[contains(text(),'Administration')]")).click();
	    
//	    wait=new WebDriverWait(dr, 20);
//		wait.until(ExpectedConditions.titleContains(""));
	     
	}

	@Given("^login as admin$")
	public void login_as_admin() throws Throwable {
		//System.out.println("login as admin");
		dr.findElement(By.xpath("//input[@name='login']")).sendKeys("admin");
		dr.findElement(By.xpath("//input[@name='password']")).sendKeys("admin");
		dr.findElement(By.xpath("//input[@name='DoLogin']")).click();
		
	}

	@When("^verify table name as admin menu$")
	public void verify_table_name_as_admin_menu() throws Throwable {
		String table_name = dr.findElement(By.xpath("//table//table//th[contains(text(),'Administration Menu')]")).getText();
	    //System.out.println(table_name);
	    al = (ArrayList) dr.findElements(By.xpath("//table//table[2]/tbody/tr"));
	    log.info(table_name);
	}

	@Then("^verify for categories$")
	public void verify_for_categories() throws Throwable {
		if((al.get(0)).getText().contains("Categories")) {
			log.info("Categories Verified");
		}
	     
	}

	@Then("^verify for editorial categories$")
	public void verify_for_editorial_categories() throws Throwable {
		if((al.get(1)).getText().contains("Editorial Categories")) {
			log.info("Editorial Categories Verified");
		}
	}

	@Then("^verify for editorial products$")
	public void verify_for_editorial_products() throws Throwable {
		if((al.get(2)).getText().contains("Editorial Products")) {
			log.info("Editorial Products Verified");
		}
	}

	@Then("^verify for Orders$")
	public void verify_for_Orders() throws Throwable {
		if((al.get(3)).getText().contains("Orders")) {
			log.info("Orders Verified");
		}
	}

	@Then("^verify for Products$")
	public void verify_for_Products() throws Throwable {
		if((al.get(4)).getText().contains("Products")) {
			log.info("Products Verified");
		} 
	}

	@Then("^verify for Statuses$")
	public void verify_for_Statuses() throws Throwable {
		if((al.get(5)).getText().contains("Statuses")) {
			log.info("Statuses Verified");
		}
	}

	@Then("^verify for Users$")
	public void verify_for_Users() throws Throwable {
		if((al.get(6)).getText().contains("Users")) {
			log.info("Users Verified");
		}
	}
}
