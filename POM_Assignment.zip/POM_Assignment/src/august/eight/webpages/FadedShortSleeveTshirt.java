package august.eight.webpages;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FadedShortSleeveTshirt {
	WebDriverWait wait;
	WebDriver dr;
	public FadedShortSleeveTshirt(WebDriver dr) {
		this.dr = dr;
	}
	public ArrayList verify() {
		By pname = By.xpath("//*[@id=\"center_column\"]/div/div/div[3]/h1");
		By pprice = By.xpath("//*[@id=\"our_price_display\"]");
		
		String p_name = dr.findElement(pname).getText();
		String p_price = dr.findElement(pprice).getText();
		float p_price_val = Float.parseFloat(p_price.replaceAll("[^0-9.]+", ""));
		ArrayList al = new ArrayList();
		al.add(p_name);
		al.add(p_price_val);
		return al;	
	}
	public void addcart() {
		By addcart = By.xpath("//*[@id=\"add_to_cart\"]/button");
		dr.findElement(addcart).click();
	}
	public void proceed_checkout() {
		By checkout = By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a");
		wait=new WebDriverWait(dr, 20);
		wait.until(ExpectedConditions.elementToBeClickable(checkout));
		dr.findElement(checkout).click();
	}
}
