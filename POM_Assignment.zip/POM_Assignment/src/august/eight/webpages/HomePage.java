package august.eight.webpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
	WebDriver dr;
	public HomePage(WebDriver dr) {
		this.dr = dr;
	}
	public void click_signin() {
		By signin = By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]//a[contains(text(),'Sign in')]");
		dr.findElement(signin).click();
		
	}
	
}
