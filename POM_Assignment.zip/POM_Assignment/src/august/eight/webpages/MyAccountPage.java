package august.eight.webpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class MyAccountPage {
	WebDriver dr;
	public MyAccountPage(WebDriver dr) {
		this.dr = dr;
	}
	public String dresses() {
		Actions act = new Actions(dr);
		Action ac = act
				.moveToElement(dr.findElement(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[2]/a")))
				.moveToElement(dr.findElement(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[2]/ul/li[1]/a")))
				.click()
				.build();
		ac.perform();
		return dr.getTitle();
	}
	public String tshirt() {
		Actions act = new Actions(dr);
		Action ac = act
				.moveToElement(dr.findElement(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[3]/a")))
				.click()
				.build();
		ac.perform();
		return dr.getTitle();
	}
	
}
