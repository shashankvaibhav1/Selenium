package august.eight.webpages;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class CasualDress {
	WebDriver dr;
	public CasualDress(WebDriver dr) {
		this.dr = dr;
	}
	public ArrayList casual_dresses() {
		ArrayList al = new ArrayList();
		if((dr.findElement(By.xpath("//*[@id=\"center_column\"]/h1/span[1]")).getText()).equals("CASUAL DRESSES ")) {
			String p_name = dr.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li/div/div[2]/h5/a")).getText();
			String price = dr.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li/div/div[2]/div[1]/span")).getText();
			Float price_val = Float.parseFloat(price.replaceAll("[^0-9.]+", ""));
			//System.out.println(p_name+"\n"+price_val);
			al.add(p_name);
			al.add(price_val);
			Actions act = new Actions(dr);
			Action ac = act
					.moveToElement(dr.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li/div")))
					.moveToElement(dr.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li/div/div[2]/div[2]/a[2]/span")))
					.click()
					.build();
			ac.perform();
		}
		return al;
	}
	
}
