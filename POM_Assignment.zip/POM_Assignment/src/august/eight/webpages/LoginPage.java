package august.eight.webpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {
	WebDriver dr;
	WebDriverWait wait;
	String user = "abcdz1232@gmail.com";
	String pass = "abcdef";
	
	public LoginPage(WebDriver dr) {
		this.dr = dr;
	}
	public String login_account() {
		By email = By.xpath("//*[@id=\"email\"]");
		By passwd = By.xpath("//*[@id=\"passwd\"]");
		By click = By.xpath("//*[@id=\"SubmitLogin\"]");
		dr.findElement(email).sendKeys(user);
		dr.findElement(passwd).sendKeys(pass);
		dr.findElement(click).click();
		return dr.getTitle();
	}
	public String create_account() {
		By email = By.xpath("//*[@id=\"email_create\"]");
		By c_acc = By.xpath("//*[@id=\"SubmitCreate\"]");
		By title = By.xpath("//*[@id=\"id_gender1\"]");
		By c_fname = By.xpath("//*[@id=\"customer_firstname\"]");
		By c_lname = By.xpath("//*[@id=\"customer_lastname\"]");
		By passwd = By.xpath("//*[@id=\"passwd\"]");
		By day = By.xpath("//*[@id=\"days\"]//*[contains(text(),'15')]");
		By month = By.xpath("//*[@id=\"months\"]//*[contains(text(),'May')]");
		By year = By.xpath("//*[@id=\"years\"]//*[contains(text(),'1997')]");
		By fname = By.xpath("//*[@id=\"firstname\"]");
		By lname = By.xpath("//*[@id=\"lastname\"]");
		By add1 = By.xpath("//*[@id=\"address1\"]");
		By city = By.xpath("//*[@id=\"city\"]");
		By state = By.xpath("//*[@id=\"id_state\"]//*[contains(text(),'Indiana')]");
		By zip = By.xpath("//*[@id=\"postcode\"]");
		By country = By.xpath("//*[@id=\"id_country\"]//*[contains(text(),'United States')]");
		By phone = By.xpath("//*[@id=\"phone_mobile\"]");
		By alias = By.xpath("//*[@id=\"alias\"]");
		
		dr.findElement(email).sendKeys(user);
		dr.findElement(c_acc).click();
		wait=new WebDriverWait(dr, 20);
		wait.until(ExpectedConditions.elementToBeClickable(title));
		dr.findElement(title).click();
		dr.findElement(c_fname).sendKeys("ABC");
		dr.findElement(c_lname).sendKeys("XYZ");
		dr.findElement(passwd).sendKeys(pass);
		dr.findElement(day).click();
		dr.findElement(month).click();
		dr.findElement(year).click();
		dr.findElement(fname).sendKeys("ABC");
		dr.findElement(lname).sendKeys("XYZ");
		dr.findElement(add1).sendKeys("ABCDEFG");
		dr.findElement(city).sendKeys("TUVWXYZ");
		dr.findElement(state).click();
		dr.findElement(zip).sendKeys("12345");
		dr.findElement(country).click();
		dr.findElement(phone).sendKeys("1234567890");
		dr.findElement(alias).sendKeys("My address");
		dr.findElement(By.xpath("//*[@id=\"submitAccount\"]")).click();
		
		return dr.getTitle();
		
	}
	
	
}
