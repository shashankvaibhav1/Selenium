package august.eight.testng.test;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import org.testng.annotations.Test;

import august.eight.webpages.*;

public class test1 {
	
	WebDriver dr;
	HomePage hp;
	LoginPage lp;
	MyAccountPage map;
	CasualDress cd;
	Tshirt t;
	PrintedDress pd;
	FadedShortSleeveTshirt fsst;
	@BeforeMethod
	public void beforeMethod() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_version_75.exe");
		dr = new ChromeDriver();
		dr.manage().window().maximize();
		dr.get("http://automationpractice.com/index.php");
		login();
	}
	//@Test
	public void register() {
		hp = new HomePage(dr);
		hp.click_signin();
		lp = new LoginPage(dr);
		String my_acc_title = lp.create_account();
		if(my_acc_title.equals("My account - My Store")) {
			System.out.println("sucess");
		}
	}
	//@Test
	public void login() {
		hp = new HomePage(dr);
		hp.click_signin();
		lp = new LoginPage(dr);
		String my_acc_title = lp.login_account();
		if(my_acc_title.equals("My account - My Store")) {
			System.out.println("sucess");			
		}
	}
	@Test
	public void casual_dress() {
		map = new MyAccountPage(dr);
		String dress_title = map.dresses();
		if(dress_title.equals("Casual Dresses - My Store")) {
			cd = new CasualDress(dr);
			ArrayList ex = cd.casual_dresses();
			pd = new PrintedDress(dr);
			ArrayList ac = pd.verify();
//			Assert.assertEquals(ac.get(0), ex.get(0));
//			Assert.assertEquals(ac.get(1), ex.get(1));
			Assert.assertEquals(ac, ex);
			pd.addcart();
			pd.proceed_checkout();
		}
	}
	@Test
	public void tshirt() {
		map = new MyAccountPage(dr);
		String dress_title = map.tshirt();
		if(dress_title.equals("T-shirts - My Store")) {
			t = new Tshirt(dr);
			ArrayList ex = t.tshirt();
			fsst = new FadedShortSleeveTshirt(dr);
			ArrayList ac = fsst.verify();
//			Assert.assertEquals(ac.get(0), ex.get(0));
//			Assert.assertEquals(ac.get(1), ex.get(1));
			Assert.assertEquals(ac, ex);
			fsst.addcart();
			fsst.proceed_checkout();
			
		}
	}
	
}
