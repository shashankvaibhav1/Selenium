package maven.august.six;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class testcase {
	
	WebDriver dr;
	
	@BeforeClass
	public void bc() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_version_75.exe");
		dr = new ChromeDriver();
		By uname = By.xpath("//*[@id=\"user-name\"]");
		By pass = By.xpath("//*[@id=\"password\"]");
		By btn = By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]");
		By cart = By.xpath("//*[@id=\"shopping_cart_container\"]/a");
		dr.get("https://www.saucedemo.com/");
		dr.findElement(uname).sendKeys("standard_user");
		dr.findElement(pass).sendKeys("secret_sauce");
		dr.findElement(btn).click();
		ArrayList ap = new ArrayList();
		ArrayList ac = new ArrayList();
		for(int i=1; i<4; i++) {
			ap.add(add_product(i));
		}
		dr.findElement(cart).click();
		for(int i=1;i<4;i++) {
			ac.add(cart(i));
		}
		if(ap.equals(ac)) {
			System.out.println("Total Cart Same");
		}
		
	}
//	public ArrayList abc() {
//		ArrayList al = new ArrayList();
//		al.add("asdd");
//		al.add(233);
//		return al;
//	}
	public ArrayList add_product(int i) {
		ArrayList al = new ArrayList();
		By product = By.xpath("//*[@id=\"inventory_container\"]/div/div["+i+"]/div[3]/button");
		By product_name = By.xpath("//*[@id=\"inventory_container\"]/div/div["+i+"]/div[2]/a/div");
		By product_price = By.xpath("//*[@id=\"inventory_container\"]//*[@id=\"inventory_container\"]/div/div["+i+"]/div[3]/div");
		dr.findElement(product).click();
		String pname = dr.findElement(product_name).getText();
//		System.out.println(pname);
		String price = dr.findElement(product_price).getText();
		float price_val = Float.parseFloat(price.replaceAll("[^0-9.]+", ""));
//		System.out.println(price_val);
		al.add(pname);
		al.add(price_val);
		return al;
	}
	public ArrayList cart(int i) {
		ArrayList al = new ArrayList();
		By product_name = By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div["+(2+i)+"]/div[2]/a/div");
		String pname = dr.findElement(product_name).getText();
//		System.out.println(pname);
		By product_price = By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div["+(2+i)+"]/div[2]/div[2]/div");
		String price = dr.findElement(product_price).getText();
		float price_val = Float.parseFloat(price.replaceAll("[^0-9.]+", ""));
//		System.out.println(price_val);
		al.add(pname);
		al.add(price_val);
		return al;
	}

	@AfterClass
	public void ac() {
		dr.quit();
	}
}
